#ifndef CHESS_PIECE_H
#define CHESS_PIECE_H

#include "common.h"

typedef struct 
{
	ChessPieceType type;
	Camp camp;
	int strength;
	int x, y;
	int isAlive;
} ChessPiece;

// 这里可以添加其他棋子相关的函数原型

#endif // CHESS_PIECE_H
