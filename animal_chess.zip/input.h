#ifndef  __INPUT_H__
#define  __INPUT_H__
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>

#include <linux/input.h>
#include <string.h>
#include "lcd.h"
#include "chess_board.h"

int *calculate(int x0, int y0) ;
void get_input(int fd, int *x0, int *y0, int *x1, int *y1);
void *process_input(void *arg);


#endif 
