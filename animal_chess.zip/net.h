#ifndef  __NET_H__
#define  __NET_H__
#include "chess_board.h"
#include "chess_piece.h"
int TCP_Server_Init(const char *ip );
int TCP_Server_Uninit();
int TCP_Client_Init();
int TCP_Client_Uninit();
void *recv_frame_data(void *arg);
void *send_frame_data(void *arg);
void *connect_handler(void *arg);
void *connect_server(void *arg);

extern int server_sockfd;
extern int client_sockfd;
extern int  NET_PORT;
extern ChessBoard board;
#endif
