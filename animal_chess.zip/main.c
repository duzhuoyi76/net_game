#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include "lcd.h"
#include "input.h"
#include <dirent.h>
#include "chess_board.h"
#include "chess_piece.h"
#include "common.h"
#include <signal.h>
#include "lcd.h"
#include <stdio.h>
#include "net.h"
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <linux/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>

ChessBoard board;
pthread_t tid;
int color;
extern int flag_move;

int beat_confirm()
{
	
	int x0,y0,x1,y1;
	int fd = open("/dev/input/event0", O_RDONLY);
	if(fd == -1)
	{
		perror("open event0 failed");
		return -1;
	}
	
	while(1)
	{
		get_input(fd, &x0, &y0, &x1, &y1);
		if(abs(x1-x0)<=50 && abs(y1-y0)<=50)
		{
			printf("===========click(%d,%d)==========\n", x0*800/1024, y0*480/600);
			if(x0 >= 225 && x0 <= 205 + 140 && y0 >= 160 + 105 && y0 <= 160 + 145)
			{
				return RED;
			}
			else if(x0 >= 205 + 160 && x0 <= 205 + 280 && y0 >= 160 + 105 && y0 <= 160 + 145)//点击确认
			{
				return BLUE;
			}
		}
	}
	
	close(fd);
	return -1;
}

int myselect()
{
	lcd_draw_jpg("select.jpg",205, 160);
	int k = beat_confirm();
	if(k == RED)
		color = RED;
	else if(k == BLUE)
		color = BLUE;
	return 0;
}


//int main(int argc, char const *argv[])
//{
//	NET_PORT = atoi(argv[3]);
//	//初始化
//
//	lcd_init();
//	lcd_draw_jpg("grass.jpg",0,0);
//	lcd_draw_jpg("restart.jpg",631,75);
//	lcd_draw_jpg("mylose.jpg",631,225);
//	lcd_draw_jpg("peace.jpg",631,375);
//	myselect();
////	lcd_draw_jpg("water.jpg",204,68);
////	lcd_draw_jpg("water.jpg",204,272);
//	initBoard();
//	drawBoard();
//	printf_piece();
//	printf_landform();
//	TCP_Server_Init(argv[1]);
//	TCP_Client_Init();
//	pthread_t tid1;
//	pthread_create(&tid1, NULL, connect_server, (void*)argv[2]);
//
//	
//	while (1)
//	{
//		struct sockaddr_in	srcAddr;//定义一个保存客户端的以太网的地址结构
//		memset(&srcAddr, 0, sizeof(srcAddr));//把结构体清空
//		socklen_t addrlen=sizeof(srcAddr);
//		int accefd = accept(server_sockfd, (struct sockaddr *)&srcAddr, &addrlen);
//		if(accefd != -1)
//		{
//			printf("connect from %s(%d)!\n", inet_ntoa(srcAddr.sin_addr), ntohs(srcAddr.sin_port));
//			pthread_create(&tid, NULL, connect_handler, &accefd);
//			
//		}
//	}
//	TCP_Server_Uninit();
//	TCP_Client_Uninit();
//	lcd_uninit();
//	return 0;
//}

int main(int argc, char const *argv[])
{
	if (argc < 4) {
		fprintf(stderr, "Usage: %s <server_ip> <client_ip> <port>\n", argv[0]);
		exit(EXIT_FAILURE);
	}
	
	NET_PORT = atoi(argv[3]);
	
	// 初始化
	lcd_init();
	lcd_draw_jpg("grass.jpg",0,0);
	lcd_draw_jpg("restart.jpg",631,20);
	lcd_draw_jpg("mylose.jpg",631,115);
	lcd_draw_jpg("peace.jpg",631,210);
	lcd_draw_jpg("agree.jpg",631,305);
	lcd_draw_jpg("disagree.jpg",631,400);
	myselect();
	initBoard();
	drawBoard();
	printf_piece();
	printf_landform();
	
	if (TCP_Server_Init(argv[1]) == -1) {
		fprintf(stderr, "Failed to initialize server\n");
		exit(EXIT_FAILURE);
	}
	
	if (TCP_Client_Init() == -1) {
		fprintf(stderr, "Failed to initialize client\n");
		exit(EXIT_FAILURE);
	}
	
	pthread_t tid1;
	pthread_create(&tid1, NULL, connect_server, (void*)argv[2]);
	
	while (1)
	{
		struct sockaddr_in srcAddr; // 定义一个保存客户端的以太网的地址结构
		memset(&srcAddr, 0, sizeof(srcAddr)); // 把结构体清空
		socklen_t addrlen = sizeof(srcAddr);
		int accefd = accept(server_sockfd, (struct sockaddr *)&srcAddr, &addrlen);
		if(accefd != -1)
		{
			printf("connect from %s(%d)!\n", inet_ntoa(srcAddr.sin_addr), ntohs(srcAddr.sin_port));
			pthread_create(&tid, NULL, connect_handler, &accefd);
		}
	}
	TCP_Server_Uninit();
	TCP_Client_Uninit();
	lcd_uninit();
	return 0;
}
