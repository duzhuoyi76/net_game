#ifndef COMMON_H
#define COMMON_H

#define BOARD_WIDTH 9
#define BOARD_HEIGHT 7

typedef enum {
	RAT = 1,
	CAT,
	DOG,
	WOLF,
	LEOPARD,
	TIGER,
	LION,
	ELEPHANT
} ChessPieceType;

typedef enum {
	RED = 1,
	BLUE = 2
} Camp;

typedef enum {
	LAND = 1,
	RIVER,
	RED_TRAP,
	BLUE_TRAP,
	RED_CAVE,
	BLUE_CAVE
} LandForm;

#endif // COMMON_H
