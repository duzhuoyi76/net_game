#ifndef CHESS_BOARD_H
#define CHESS_BOARD_H

#include "common.h"
#include "chess_piece.h"

typedef struct {
	ChessPiece* piece;
	LandForm landForm;
} ChessBoardCell;

typedef ChessBoardCell ChessBoard[BOARD_HEIGHT][BOARD_WIDTH];

void trap();
int isvictory();
void printf_landform();
void printf_piece();
void initBoard();//初始化
void drawBoard();//画棋子
int isPiece(int startX, int startY);//此格子是否有棋子
int isMoveValid(int startX, int startY, int endX, int endY);//移动是否合法
void movePiece(int startX, int startY, int endX, int endY);//移动
void eatPiece(int startX, int startY, int endX, int endY);//是否能吃棋子
int isLionOrTiger(ChessPiece* piece);//是否为狮子老虎
int isRiver(int x, int y);//是否为河流
int isOpponentPieceWeaker(int x, int y);//检查目标位置的棋子是否是对方的并且比当前棋子弱。
int isMouse(ChessPiece* piece);//检查棋子是否是老鼠
#endif // CHESS_BOARD_H
