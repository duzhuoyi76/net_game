#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <linux/fb.h>
#include <sys/ioctl.h>   
#include <sys/mman.h>
#include <stdlib.h>
#include <string.h>
#include "jpeglib.h"
#include "chess_board.h"
#include "chess_piece.h"
#include "common.h"

#define MAX(a,b)   ((a)>(b)?(a):(b))
#define MIN(a,b)   ((a)<(b)?(a):(b))

int fb=-1;//屏幕设备文件的文件描述符
struct fb_var_screeninfo fbinfo;//保存屏幕信息的结构体
int *plcd=NULL;//帧缓冲的首地址

/*
	lcd_init: lcd初始化函数
*/
void lcd_init(void)
{
	//1.打开屏幕设备文件  /dev/fb0
	fb = open("/dev/fb0", O_RDWR);
	if(fb == -1)
	{
		perror("open fb0 failed");
		return;
	}
	//2.获取屏幕信息
	ioctl(fb, FBIOGET_VSCREENINFO, &fbinfo);
	printf("LCD: %ld*%ld*%d\n", fbinfo.xres, fbinfo.yres, fbinfo.bits_per_pixel);
	//3.映射  mmap
	plcd = (void *)mmap(NULL, fbinfo.xres*fbinfo.yres*fbinfo.bits_per_pixel/8, PROT_READ|PROT_WRITE,
	MAP_SHARED,	fb, 0);
}

/*
	lcd_draw_point1: 在屏幕的坐标(x0,y0)处，画一个颜色值为color的像素点
*/
void lcd_draw_point1(int x0, int y0, int color)
{
	if(x0>=0 && x0<fbinfo.xres && y0>=0 && y0<fbinfo.yres)
	{
		*(plcd+fbinfo.xres*y0+x0) = color;
	}
}


/*
	lcd_draw_point: 在屏幕的坐标(x0,y0)处，画一个颜色值为color的像素点
*/
unsigned int framebuffer[480][800]={0};
static inline 
void lcd_draw_point(int x0, int y0, int color)
{
	if(x0>=0 && x0<fbinfo.xres && y0>=0 && y0<fbinfo.yres)
	{
		framebuffer[y0][x0] = color;
	}
}

void update_frame(void)
{
	memcpy(plcd, framebuffer, 800*480*4);
}


/*
	lcd_draw_rectangle: 在屏幕坐标(x0,y0)处，画一个宽为w，高为h，颜色为color的矩形
*/
void lcd_draw_rectangle(int x0, int y0, int w, int h, int color)
{
	for(int i=x0; i<x0+w; i++)
	{
		for(int j=y0; j<y0+h; j++)
		{
			lcd_draw_point(i, j, color);
		}
	}
	update_frame();
}

/*
	lcd_draw_circle: 在屏幕画一个圆心为(x0,y0),半径为 r, 颜色为color的圆
*/
void lcd_draw_circle(int x0, int y0, int r, int color)
{
	for(int i=x0-r; i<=x0+r; i++)
	{
		for(int j=y0-r; j<=y0+r; j++)
		{
			if((i-x0)*(i-x0)+(j-y0)*(j-y0) <= r*r)
			{
				lcd_draw_point(i, j, color);
			}
		}
	}
	update_frame();

}


/*
	lcd_draw_ellipse: 在屏幕画一个圆心为(x0,y0),横轴为a,纵轴为b, 颜色为color的椭圆
*/
void lcd_draw_ellipse(int x0, int y0, int a, int b, int color)
{
	for(int i=x0-a; i<=x0+a; i++)
	{
		for(int j=y0-b; j<=y0+b; j++)
		{
			if(b*b*(i-x0)*(i-x0)+a*a*(j-y0)*(j-y0) <= a*a*b*b)
			{
				lcd_draw_point(i, j, color);
			}
		}
	}
	update_frame();

}


/*
	lcd_draw_triangle: 在屏幕画一个由(x0,y0),(x1,y1),(x2,y2)确定的三角形，颜色为color
*/
void lcd_draw_triangle(int x0, int y0, int x1, int y1, int x2, int y2, int color)
{
	int x_min = MIN(MIN(x0,x1),x2);
	int x_max = MAX(MAX(x0,x1),x2);
	int y_min = MIN(MIN(y0,y1),y2);
	int y_max = MAX(MAX(y0,y1),y2); 

	int S_da = abs(x0*(y1 - y2) + x1*(y2 - y0) + x2*(y0 - y1));
	for(int i=x_min; i<= x_max; i++)
	{
		for(int j=y_min; j<=y_max; j++)
		{
			int s1 = abs(i*(y1 - y2) + x1*(y2 - j) + x2*(j - y1));
			int s2 = abs(x0*(j - y2) + i*(y2 - y0) + x2*(y0 - j));
			int s3 = abs(x0*(y1 - j) + x1*(j - y0) + i*(y0 - y1));
			if(s1+s2+s3 == S_da)
			{
				lcd_draw_point(i, j, color);
			}
		}
	}
	update_frame();
}

/*
   void lcd_draw_word(int x0,int y0,int w,int h,unsigned char *data,int color)
   在位置为(x0,y0)处显示宽为w,高为h的汉字	
*/
void lcd_draw_word(int x0,int y0,int w,int h,unsigned char *data,int color)
{
	int i,k;
	
	for(i=0;i<w*h/8;i++)//i表示第几个字节
	{
		for(k=0;k<8;k++)//k表示在该字节的第几个bit
		{
			if((data[i]<<k )&0x80)//从高位到低位判断
			{
				lcd_draw_point(x0+(i*8+k)%w,y0+i/(w/8),color);
			}
		}			
	}
	update_frame();
}

/*
	lcd_draw_bmp: 在屏幕的坐标(x0,y0)处显示 bmpname指向的bmp图片
*/
void lcd_draw_bmp(const char *bmpname, int x0, int y0)
{
	int fd = open(bmpname, O_RDONLY);
	if(fd == -1)
	{
		perror("open bmp failed");
		return;
	}
	/*读魔数*/
	unsigned char buf[2];
	lseek(fd, 0, SEEK_SET);
	read(fd, buf, 2);
	if(buf[0]!=0x42 || buf[1]!=0x4D)
	{
		printf("this picture is not bmp!\n");
		close(fd);
		return;
	}
	/*读位图数据的偏移地址*/
	int offset;
	lseek(fd, 0x0A, SEEK_SET);
	read(fd, &offset, 4);
	/*读取图片的宽度和高度*/
	int width;
	lseek(fd, 0x12, SEEK_SET);
	read(fd, &width, 4);
	int height;
	lseek(fd, 0x16, SEEK_SET);
	read(fd, &height, 4);
	/*读取图片的色深*/
	short colordepth;
	lseek(fd, 0x1C, SEEK_SET);
	read(fd, &colordepth, 2);
	printf("bmp: offset:%d width:%d height:%d colordepth:%d\n",offset,width,height,colordepth);

	if(x0==-1 || y0==-1) 
	{
		if(width<800 || height<480)
		{
			if(width<800)
				x0 = (800-width)/2;
			if(height<480)
				y0 = (480-height)/2;
		}
		else
		{
			x0 = 0;
			y0 = 0;
		}
	}
	
	/*读取像素数组值，并用画点函数画出来*/
	lseek(fd, offset, SEEK_SET);
	for(int i=0;i<abs(height);i++)
	{
		for(int j=0;j<width;j++)
		{
			int color=0;
			if(colordepth == 24)
			{
				read(fd, &color, 3);
			}
			else if(colordepth == 32)
			{
				read(fd, &color, 4);
			}
			lcd_draw_point(x0+j, y0+(height>0?height-1-i:i), color);
		}
		lseek(fd, (4-colordepth/8*width%4)%4, SEEK_CUR);//跳过每行的无效的填充数据
	}
	close(fd);
	update_frame();
}


/*
	lcd_draw_jpg: 在屏幕的坐标(x0,y0)处显示 jpg_name指向的jpg图片
*/

void lcd_draw_jpg(const char *jpg_name, int x0, int y0)
{
	/*
	１.　分配并初始化一个jpeg解压对象
	*/
	struct jpeg_decompress_struct dinfo; //定义了一个jpeg的解压对象
	
	struct jpeg_error_mgr jerr; //定义一个错误变量
	dinfo.err = jpeg_std_error(&jerr);
		
	jpeg_create_decompress(&dinfo); //初始化这个解压对象

	/*
	2. 指定要解压缩的图像文件
	
	*/
	FILE *infile;
	infile = fopen(jpg_name, "r");
	if (infile == NULL)
	{
		perror("fopen error");
		return ;
	}

	jpeg_stdio_src(&dinfo, infile); //为解压对象dinfo指定要解压的文件

	/*
	3. 调用jpeg_read_header()获取图像信息

	*/
	jpeg_read_header(&dinfo, TRUE);

	/*
	4. 设置jpeg解压缩对象dinfo的一些参数，可采用默认参数
	*/


	/*
	5.调用jpeg_start_decompress()启动解压过程
	jpeg_start_decompress(&dinfo); 
	调用jpeg_start_decompress(&dinfo);函数之后，JPEG解压对象dinfo中下面这几个成员变量
	将会比较有用：
	output_width:  图像的输出宽度
	output_height：　图像的输出高度
	output_component：　每个像素的分量数，也即字节数，3/4字节
		在调用jpeg_start_decompress(&dinfo); 之后往往需要为解压后的扫描线上的所有像素点分配存储空间，
	output_width * output_components(一行的字节数，output_height行)

	*/

	jpeg_start_decompress(&dinfo); 


	unsigned char *buffer = malloc(dinfo.output_width * dinfo.output_components);

	/*
	６.　读取一行或者多行扫描线数据并处理，通常的代码是这样的：
	
	//output_scanline表示扫描的总行数
	//output_height表示图像的总行数
	while (dinfo.output_scanline < dinfo.output_height)
	{
		jpeg_read_scanlines(&dinfo, &buffer, 1);

		//deal with scanlines . RGB/ARGB
	}
	*/

	//output_scanline表示扫描的总行数
	//output_height表示图像的总行数
	if(x0==-1 || y0==-1)
	{
		if(dinfo.output_width<800 || dinfo.output_height<480)
		{
			if(dinfo.output_width<800)
				x0 = (800-dinfo.output_width)/2;
			if(dinfo.output_height<480)
				y0 = (480-dinfo.output_height)/2;
		}
		else
		{
			x0 = 0;
			y0 = 0;
		}
	}
	while (dinfo.output_scanline < dinfo.output_height)
	{
		jpeg_read_scanlines(&dinfo, &buffer, 1); //dinfo.output_scanline + 1

		//deal with scanlines . RGB/ARGB
		int x; //一行的像素点数量

		char *p = buffer;
		for (x = 0; x < dinfo.output_width; x++)
		{
			unsigned char r, g, b, a = 0;
			int color;
			if (dinfo.output_components == 3)
			{
				r = *p++;
				g = *p++;
				b = *p++;
			} else if (dinfo.output_components == 4)
			{
				a = *p++;
				r = *p++;
				g = *p++;
				b = *p++;
			}
			color = (a << 24) | (r << 16) | (g << 8) |(b) ;


			lcd_draw_point(x+x0, dinfo.output_scanline - 1 +y0,  color); 
		}
	}

	/*
	7. 调用　jpeg_finish_decompress()完成解压过程
	*/
	jpeg_finish_decompress(&dinfo);

	/*
	８.调用jpeg_destroy_decompress()释放jpeg解压对象dinfo
	jpeg_destroy_decompress(&dinfo);
	*/
	jpeg_destroy_decompress(&dinfo);
	free(buffer);
	fclose(infile);

	update_frame();
}

/*
	lcd_uninit: lcd解初始化函数
*/
void lcd_uninit(void)
{
	//5.解映射 munmap
	munmap(plcd, fbinfo.xres*fbinfo.yres*fbinfo.bits_per_pixel/8);
	//6.关闭屏幕设备文件
	close(fb);
}


