#ifndef   __LCD_H__
#define   __LCD_H__
void lcd_init(void);
void lcd_draw_point(int x0, int y0, int color);
void lcd_uninit(void);
void lcd_draw_rectangle(int x0, int y0, int w, int h, int color);
void lcd_draw_word(int x0,int y0,int w,int h,unsigned char *data,int color);
void lcd_draw_circle(int x0, int y0, int r, int color);
void lcd_draw_ellipse(int x0, int y0, int a, int b, int color);
void lcd_draw_triangle(int x0, int y0, int x1, int y1, int x2, int y2, int color);
void lcd_draw_bmp(const char *bmpname, int x0, int y0);
void lcd_draw_jpg(const char *jpg_name, int x0, int y0);


#endif 

