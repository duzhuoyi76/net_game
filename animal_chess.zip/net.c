#include <stdio.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <linux/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include "lcd.h"
#include "input.h"
#include <dirent.h>
#include "chess_board.h"
#include "chess_piece.h"
#include "common.h"
#include <signal.h>
#include "lcd.h"
#include <stdio.h>
#include "net.h"
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <linux/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>


ChessBoard board;
int NET_PORT=0;       
int server_sockfd;
int client_sockfd;
char last_recv[128];
char last_send[128];
pthread_t tid1,tid;
extern int flag_move;


//int TCP_Server_Init(const char *ip )
//{
//	/*step1: 创建TCP socket套接字*/
//	server_sockfd = socket(AF_INET, SOCK_STREAM, 0);
//	if(server_sockfd == -1)
//	{
//		perror("socket failed!\n");
//		return -1;
//	}
//	
//	/*step2: bind*/
//	struct sockaddr_in	myAddr;//定义一个以太网的地址结构
//	memset(&myAddr, 0, sizeof(myAddr));//把结构体清空
//	myAddr.sin_family = AF_INET;//IPV4协议
//
//	myAddr.sin_addr.s_addr = inet_addr(ip);
//	myAddr.sin_port = htons(NET_PORT);
//	int r = bind(server_sockfd, (struct sockaddr *)&myAddr, sizeof(myAddr));
//	if(r == -1)
//	{
//		perror("bind failed");
//		exit(0);
//		return -1;
//	}
//	/*step3: listen*/
//	r = listen(server_sockfd, 64);
//	if(r == -1)
//	{
//		perror("listen failed");
//		return -1;
//	}
//	return server_sockfd;
//}

int TCP_Server_Init(const char *ip)
{
	// 创建一个服务器类型的socket
	server_sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(server_sockfd == -1)
	{
		perror("socket failed");
		return -1;
	}
	
	struct sockaddr_in serverAddr; // 定义一个以太网的地址结构
	memset(&serverAddr, 0, sizeof(serverAddr)); // 把结构体清空
	serverAddr.sin_family = AF_INET; // IPV4协议
	serverAddr.sin_addr.s_addr = inet_addr(ip);
	serverAddr.sin_port = htons(NET_PORT);
	
	if(bind(server_sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == -1)
	{
		perror("bind failed");
		close(server_sockfd);
		return -1;
	}
	
	if(listen(server_sockfd, 10) == -1)
	{
		perror("listen failed");
		close(server_sockfd);
		return -1;
	}
	
	printf("Server initialized on %s:%d\n", ip, NET_PORT); // Debugging statement
	return 0;
}


int TCP_Server_Uninit()
{
	close(server_sockfd);
}

int TCP_Client_Init()
{
	client_sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(client_sockfd == -1)
	{
		perror("socket failed");
		return -1;
	}
	printf("Client socket created: %d\n", client_sockfd); // Debugging statement
	return 0;
}

int TCP_Client_Uninit()
{
	close(client_sockfd);
}


void *recv_frame_data(void *arg)
{
	pthread_detach(pthread_self());//设置分离模式，自动释放资源
	int sockfd = *(int *)arg;
	while(1)
	{
		
		char buf[128] = {0};
		int r = read(sockfd, buf, sizeof(buf)+1);//先读长度
		if(r > 0)
		{
			if(strcmp(buf,"restart") == 0)
			{
				lcd_draw_jpg("afresh_confirm.jpg",205,160);
				strcpy(last_recv,"restart");
			}
			else if(strcmp(buf,"mylose") == 0)
			{
				lcd_draw_jpg("win.jpg",205,160);
				strcpy(last_recv,"mylose");
				pthread_cancel(tid);
			}
			else if(strcmp(buf,"peace") == 0)
			{
				lcd_draw_jpg("deuse_confirm.jpg",205,160);
				strcpy(last_recv,"peace");
			}
			else if(strcmp(buf,"agree") == 0)
			{
				if(strcmp(last_send,"restart") == 0)
				{
					initBoard();
					drawBoard();
				}
				else if(strcmp(last_send,"peace") == 0)
				{
					drawBoard();
					lcd_draw_jpg("peace.jpg",325,207);
					flag_move = 0;
				}
			}
			else if(strcmp(buf,"disagree") == 0)
			{
				drawBoard();
			}
			else
			{
				char xf1[64] = {0};
				char yf1[64] = {0};
				char x01[64] = {0};
				char y01[64] = {0};
				sscanf(buf,"%s %s %s %s",xf1, yf1, x01, y01);
				int xf = atoi(xf1);
				int yf = atoi(yf1);
				int x0 = atoi(x01);
				int y0 = atoi(y01);
				int *pos = calculate(x0,y0);
				int endX =(x0/68)*68;
				int endY =(y0/68)*68;
				printf("%d %d %d %d\n",xf,yf,x0,y0);
				
				movePiece(xf/68, yf/68, endX/68, endY/68);
				drawBoard();
				xf = 1000;
				yf = 1000;
				printf_piece();
				
				
				if(isvictory() == 2)
				{
					printf("lose!!!!!!!!!!\n");
					lcd_draw_jpg("lose.jpg",200,165);
					break;
				}
				if(isvictory() == 1)
				{
					printf("win!!!!!!!!!\n");
					lcd_draw_jpg("win.jpg",200,165);
					break;
				}
				drawBoard();
				flag_move = 1;
			}
		}
	}
}

void *connect_server(void *arg)
{
	char *ip = (char*)arg;
	while(1)
	{
		struct sockaddr_in	destAddr;//定义一个以太网的地址结构
		memset(&destAddr, 0, sizeof(destAddr));//把结构体清空
		destAddr.sin_family = AF_INET;//IPV4协议
		destAddr.sin_addr.s_addr = inet_addr(ip);
		destAddr.sin_port = htons(NET_PORT);
		int r = connect(client_sockfd, (struct sockaddr*)&destAddr, sizeof(destAddr));
		if(r == 0)
		{
			write(client_sockfd, "connect", 8);
			pthread_create(&tid, NULL, recv_frame_data, &client_sockfd);
			break;
		}
		else
		{
			perror("connect failed!");
			sleep(3);
		}
		
	}
}

//void *send_frame_data(void *arg)
//{
//	pthread_detach(pthread_self());//设置分离模式，自动释放资源
//	int sockfd = *(int *)arg;
//	while(1)
//	{
//		char buf[sizeof(board)+100];
//		strcpy(buf,(char *)board);
//		int r = write(sockfd, buf, sizeof(board));
////		if(r != sizeof(board))
////		{
////			perror("write error");
////			return NULL;
////		}
//
//	}
//
//}

void *connect_handler(void *arg)//连接处理线程函数
{
	pthread_t tid2;
	int sockfd = *(int*)arg;
	pthread_detach(pthread_self());//设置分离模式，自动释放资源
	while(1)
	{
		char buf[128]={0};
		int r = read(sockfd, buf, 128);
		printf("buf:%s\n", buf);
		
		if(r == 0)//r为0表示断开连接
		{
			printf("connect break!\n");
			close(sockfd);
			pthread_cancel(tid2);
			return NULL;
		}
		if(strcmp(buf, "connect") == 0)
		{
			pthread_create(&tid1, NULL, process_input, &sockfd);
			sleep(1);
			break;
		}
		
//		if(strcmp(buf, "restart") == 0)
//		{
//			
//		}
//		if(strcmp(buf, "giveup") == 0)
//		{
//			
//		}
	}
}




