#include "chess_piece.h"
#include "common.h"

// 这里可以添加ChessPiece相关的函数实现，例如构造函数等。
// 由于示例中没有具体的函数，以下是一个构造ChessPiece的简单例子：

ChessPiece* create_chess_piece(ChessPiece *new_piece, ChessPieceType type, Camp camp, int strength) 
{
//	ChessPiece* new_piece = (ChessPiece*)malloc(sizeof(ChessPiece));
	if (new_piece) 
	{
		new_piece->type = type;
		new_piece->camp = camp;
		new_piece->strength = strength;
		new_piece->x = 0;
		new_piece->y = 0;
		new_piece->isAlive = 1;
	}
	return new_piece;
}
