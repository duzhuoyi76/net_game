#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>

#include <linux/input.h>
#include <string.h>
#include "lcd.h"
#include "chess_board.h"
#include "chess_piece.h"
#include "common.h"

int xf = 1000;
int yf = 1000;

extern ChessBoard board;
extern int color;
extern char last_recv[128];
extern char last_send[128];
int flag_click;
int flag_move;

int *calculate(int x0, int y0) 
{
	const int total_width = 612;
	const int total_height = 480;
	const int area_width = 68;
	const int area_height = 68;
	const int num_rows = 7;
	const int num_columns = 9;
	static int pos[2] = {0}; // 使用static来保持数组内容
	
	// 检查触摸点是否在屏幕范围内
	if (x0 < 0 || x0 >= total_width || y0 < 0 || y0 >= total_height) 
	{
		return NULL; // 返回NULL指针
	}
	
	// 计算触摸点所在的列和行
	int column_index = x0 / area_width;
	int row_index = y0 / area_height;
	
	// 检查触摸点是否在区域范围内
	if (column_index >= num_columns || row_index >= num_rows) 
	{
		return NULL; // 返回NULL指针
	}
	
	// 计算左上角的坐标
	pos[0] = column_index * area_width;
	pos[1] = row_index * area_height;
	
	return pos; // 返回指向pos数组的指针
}

void get_input(int fd, int *x0, int *y0, int *x1, int *y1)
{
	struct input_event et;
	
	int flag_x=0,flag_y=0;
	while(1)
	{
		int r = read(fd, &et, sizeof(et));
		if(r == sizeof(et))
		{
			if(et.type==EV_ABS && et.code==ABS_X)
			{
				if(flag_x == 0)
				{
					flag_x = 1;
					*x0 = et.value*800/1024; 
				}
				*x1 = et.value*800/1024;
			}
			if(et.type==EV_ABS && et.code==ABS_Y)
			{
				if(flag_y == 0)
				{
					flag_y = 1;
					*y0 = et.value*480/600; 
				}
				*y1 = et.value*480/600;
			}
			if(et.type==EV_KEY && et.code==BTN_TOUCH && et.value==0)//触摸动作结束
			{
				break;
			}
		}
	}
}

//void * process_input(void *arg)
//{
//	int sockfd = *(int*)arg;
//	int x0,y0,x1,y1;
//	int fd = open("/dev/input/event0", O_RDONLY);
//	if(fd == -1)
//	{
//		perror("open event0 failed");
//		return NULL;
//	}
//	
//	flag_click = 0;
//	while(1)
//	{
//		get_input(fd, &x0, &y0, &x1, &y1);
//		if(abs(x1-x0)<=50 && abs(y1-y0)<=50)//点击
//		{
//			int *pos = calculate(x0,y0);
//			if (pos != NULL) 
//			{
//				printf("===========click(%d,%d)==========\n", x0, y0);
//				if (flag_click == 0) //没点过这个格子
//				{
//					if(isPiece(x0/68,y0/68))
//					{
//						printf("choose\n");
//						xf = (x0/68)*68;
//						yf = (y0/68)*68;
//						lcd_draw_jpg("choose.jpg", xf,yf);//覆盖选择图片
//						flag_click = 1;
//						
//					}
//					else
//					{
//						printf("no piece\n");
//					}
//				}
//				else//第二次点击
//				{
//					int endX =(x0/68)*68;
//					int endY =(y0/68)*68;
//					printf("%d %d %d %d\n",xf,yf,x0,y0);
//					if(((abs(xf-pos[0])>=68)&&(abs(xf-pos[0])<=136)) || ((abs(yf-pos[1])>=68)&&(abs(yf-pos[1])<=136)))
//					{
//						
//						if(isMoveValid(xf/68, yf/68, endX/68, endY/68))
//						{
//							movePiece(xf/68, yf/68, endX/68, endY/68);
//							drawBoard();
//							flag_click = 0;
//							xf = 1000;
//							yf = 1000;
//							printf_piece();
//						}
//						else
//						{
//							lcd_draw_jpg("renew.jpg", pos[0], pos[1]);//显示无效移动
//							printf("renew2\n");
//							usleep(500000); // 等待0.5秒
//							drawBoard(board);
//							flag_click = 0;
//							printf_piece();
//						}
//					}
//					else
//					{
//						lcd_draw_jpg("renew.jpg", pos[0], pos[1]);//显示无效移动
//						printf("renew3\n");
//						usleep(500000); // 等待0.5秒
//						drawBoard(board);
//						flag_click = 0;
//					}
//					if(isvictory() == 2)
//					{
//						printf("win!!!!!!!!!!\n");
//						break;
//					}
//					if(isvictory() == 1)
//					{
//						printf("lose!!!!!!!!!\n");
//						break;
//					}
//					
//					char buf[128] = {0};
//					sprintf(buf,"%d %d %d %d", xf, yf, x0, y0);
//					int r = write(sockfd,buf,strlen(buf)+1);
//					if(r > 0)
//					{
//						printf("write succeed!\n");
//					}
//					else if(r == -1)
//					{
//						perror("write failed!");
//					}
//				}
//			}
//			
//			if(x0>=750 && x0<800 && y0>=0 && y0<50)//点击右上角，结束程序
//				break;//结束程序
//		}
//	}
//	close(fd);
//}

void *process_input(void *arg)
{
	int sockfd = *(int*)arg;
	printf("Socket descriptor in process_input: %d\n", sockfd); // Debugging statement
	int x0, y0, x1, y1;
	int fd = open("/dev/input/event0", O_RDONLY);
	if(fd == -1)
	{
		perror("open event0 failed");
		return NULL;
	}
	
	flag_click = 0;
	while(1)
	{
		get_input(fd, &x0, &y0, &x1, &y1);
		printf("Click detected at: (%d, %d)\n", x0, y0); // Debugging statement
		char message[128] = {0};
		if((x0 >= 631 && x0 <= 751) && (y0 >= 20 && y0 <= 95)) //restart
		{
			printf("===========点击重新开始==========\n");
			strcpy(message,"restart");
			strcpy(last_send,"restart");
			int r = write(sockfd,message,128);
			if(r > 0 )
			{
				printf("successly send %s\n",message);
			}
			else if(r == -1)
			{
				printf("send %s failed\n",message);
			}
		}
		else if((x0 >= 631 && x0 <= 751) && (y0 >= 115 && y0 <= 190)) //认输
		{
			printf("===========点击认输==========\n");
			strcpy(message,"mylose");
			strcpy(last_send,"mylose");
			int r = write(sockfd, message, 128);
			if(r > 0 )
			{
				lcd_draw_jpg("lose.jpg",205,160);
				printf("successly send %s\n",message);
				//strcpy(last_mesg,"afresh");
				printf("last_mesg %s\n",last_send);
			}
			else if(r == -1)
			{
				printf("send %s failed\n",message);
			}
		}
		else if((x0 >= 631 && x0 <= 751) && (y0 >= 210 && y0 <= 285)) //求和
		{
			printf("===========点击求和==========\n");
			strcpy(message,"peace");
			strcpy(last_send,"peace");
			int r = write(sockfd, "peace", 128);
			if(r > 0 )
			{
				printf("successly send %s\n",message);
				//strcpy(last_mesg,"afresh");
				printf("last_mesg %s\n",last_send);
			}
			else if(r == -1)
			{
				printf("send %s failed\n",message);
			}
		}
		else if((x0 >= 631 && x0 <= 751) && (y0 >= 305 && y0 <= 380)) //同意
		{
			strcpy(message,"agree");
			int r = write(sockfd, "agree", 128);
			if(r > 0 )
			{
				printf("successly send %s\n",message);
				//strcpy(last_mesg,"afresh");
				printf("last_mesg %s\n",last_send);
			}
			else if(r == -1)
			{
				printf("send %s failed\n",message);
			}
			if(strcmp(last_recv,"restart") == 0)
			{
				initBoard();
				drawBoard();
			}
			else if(strcmp(last_recv,"peace") == 0)
			{
				drawBoard();
				lcd_draw_jpg("peace.jpg",325,207);
				flag_move = 0;
			}
		}
		else if((x0 >= 631 && x0 <= 751) && (y0 >= 400 && y0 <= 475)) //不同意
		{
			strcpy(message,"disagree");
			int r = write(sockfd, "disagree", 128);
			if(r > 0 )
			{
				printf("successly send %s\n",message);
				//strcpy(last_mesg,"afresh");
				printf("last_mesg %s\n",last_send);
			}
			else if(r == -1)
			{
				printf("send %s failed\n",message);
			}
			drawBoard();
		}
		else if(abs(x1-x0)<=50 && abs(y1-y0)<=50)
		{
			
			int *pos = calculate(x0, y0);
			int endX = (x0/68) * 68;
			int endY = (y0/68) * 68;
			printf("点击位置(%d,%d) 归算为(%d,%d)\n", x0, y0, endX, endY);
			if(flag_click == 0)
			{
				xf = endX;
				yf = endY;
//				if(isPiece(pos[0],pos[1]))
//				{
				lcd_draw_jpg("choose.jpg", pos[0], pos[1]); //显示选中					
				flag_click++;
//				else
//				{
//					lcd_draw_jpg("renew.jpg",pos[0],pos[1]);
//					drawBoard();
//					continue;
//				}
				
			}
			else if(flag_click == 1)
			{
				if (((abs(xf - pos[0]) >= 68) && (abs(xf - pos[0]) <= 136)) || ((abs(yf - pos[1]) >= 68) && (abs(yf - pos[1]) <= 136)))
				{
					if (isMoveValid(xf/68, yf/68, endX/68, endY/68)&&flag_move == 1)
					{
						movePiece(xf/68, yf/68, endX/68, endY/68);
						drawBoard();
						printf_piece();
						char buf[128] = {0};
						sprintf(buf, "%d %d %d %d", xf, yf, endX, endY);
						write(sockfd, buf, strlen(buf)+1);
						flag_move = 0;
					}
					else
					{
						flag_click = 0;
						lcd_draw_jpg("renew.jpg", pos[0], pos[1]); //显示无效移动
						printf("renew2\n");
						usleep(500000); //等待0.5秒
						drawBoard();
						printf_piece();
					}
				}
				else
				{
					flag_click = 0;
					lcd_draw_jpg("renew.jpg", pos[0], pos[1]); //显示无效移动
					printf("renew3\n");
					usleep(500000); //等待0.5秒
					drawBoard();
				}
				flag_click = 0;
			}
			if(isvictory() == 1)
			{
				printf("lose!!!!!!!!!!\n");
				lcd_draw_jpg("lose.jpg",200,165);
				break;
			}
			if(isvictory() == 2)
			{
				printf("win!!!!!!!!!\n");
				lcd_draw_jpg("win.jpg",200,165);
				break;
			}
		}
		sleep(1);
		if(strcmp(message,"mylose") == 0)
		{

			return NULL;
		}
	}
	close(fd);
}


