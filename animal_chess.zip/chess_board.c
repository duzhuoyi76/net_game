#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "chess_board.h"
#include "chess_piece.h"
#include "common.h"
#include "lcd.h"
#include "input.h"

extern ChessBoard board;
extern int color;
extern int flag_move;
void initBoard() 
{
	// 初始化棋盘和棋子
	if(color == RED)
	{
		flag_move = 1;
	}
	else if(color == BLUE)
	{
		flag_move = 0;
	}
	for (int i = 0; i < 9; i++) 
	{
		for (int j = 0; j < 7; j++) 
		{
			board[j][i].piece = NULL;
			if(((i == 3 || i == 4 || i == 5) && (j == 1 || j == 2 || j == 4 || j == 5)))//河的范围
			{
				board[j][i].landForm = RIVER;
			}
			else
			{
				board[j][i].landForm = LAND;
			}
		}
	}
	board[3][0].landForm = RED_CAVE;
	board[2][0].landForm = RED_TRAP;
	board[3][1].landForm = RED_TRAP;
	board[4][0].landForm = RED_TRAP;
	
	board[3][8].landForm = BLUE_CAVE;
	board[3][7].landForm = BLUE_TRAP;
	board[2][8].landForm = BLUE_TRAP;
	board[4][8].landForm = BLUE_TRAP;
	
	
	// 创建棋子
	ChessPiece* redTiger = (ChessPiece*)malloc(sizeof(ChessPiece));
	redTiger->type = TIGER;
	redTiger->camp = RED;
	redTiger->strength = 6;
	redTiger->x = 0;
	redTiger->y = 0;
	redTiger->isAlive = 1;
	
	board[redTiger->y][redTiger->x].piece = redTiger;
	
	
	ChessPiece* redElephant = (ChessPiece*)malloc(sizeof(ChessPiece));
	redElephant->type = ELEPHANT;
	redElephant->camp = RED;
	redElephant->strength = 8;
	redElephant->x = 2;
	redElephant->y = 0;
	redElephant->isAlive = 1;
	board[redElephant->y][redElephant->x].piece = redElephant;
	
	ChessPiece* redCat = (ChessPiece*)malloc(sizeof(ChessPiece));
	redCat->type = CAT;
	redCat->camp = RED;
	redCat->strength = 2;
	redCat->x = 1;
	redCat->y = 1;
	redCat->isAlive = 1;
	
	board[redCat->y][redCat->x].piece = redCat;
	
	ChessPiece* redWolf = (ChessPiece*)malloc(sizeof(ChessPiece));
	redWolf->type = WOLF;
	redWolf->camp = RED;
	redWolf->strength = 4;
	redWolf->x = 2;
	redWolf->y = 2;
	redWolf->isAlive = 1;
	
	board[redWolf->y][redWolf->x].piece = redWolf;
	
	ChessPiece* redLeopard = (ChessPiece*)malloc(sizeof(ChessPiece));
	redLeopard->type = LEOPARD;
	redLeopard->camp = RED;
	redLeopard->strength = 5;
	redLeopard->x = 2;
	redLeopard->y = 4;
	redLeopard->isAlive = 1;
	
	board[redLeopard->y][redLeopard->x].piece = redLeopard;
	
	ChessPiece* redDog = (ChessPiece*)malloc(sizeof(ChessPiece));
	redDog->type = DOG;
	redDog->camp = RED;
	redDog->strength = 3;
	redDog->x = 1;
	redDog->y = 5;
	redDog->isAlive = 1;
	
	board[redDog->y][redDog->x].piece = redDog;
	
	ChessPiece* redLion = (ChessPiece*)malloc(sizeof(ChessPiece));
	redLion->type = LION;
	redLion->camp = RED;
	redLion->strength = 7;
	redLion->x = 0;
	redLion->y = 6;
	redLion->isAlive = 1;
	
	board[redLion->y][redLion->x].piece = redLion;
	
	ChessPiece* redRat = (ChessPiece*)malloc(sizeof(ChessPiece));
	redRat->type = RAT;
	redRat->camp = RED;
	redRat->strength = 1;
	redRat->x = 2;
	redRat->y = 6;
	redRat->isAlive = 1;
	
	board[redRat->y][redRat->x].piece = redRat;
	
	
	
	// 创建棋子
	ChessPiece* blueTiger = (ChessPiece*)malloc(sizeof(ChessPiece));
	blueTiger->type = TIGER;
	blueTiger->camp = BLUE;
	blueTiger->strength = 6;
	blueTiger->x = 8;
	blueTiger->y = 6;
	blueTiger->isAlive = 1;
	//反
	board[blueTiger->y][blueTiger->x].piece = blueTiger;
	
	
	ChessPiece* blueElephant = (ChessPiece*)malloc(sizeof(ChessPiece));
	blueElephant->type = ELEPHANT;
	blueElephant->camp = BLUE;
	blueElephant->strength = 8;
	blueElephant->x = 6;
	blueElephant->y = 6;
	blueElephant->isAlive = 1;
	
	board[blueElephant->y][blueElephant->x].piece = blueElephant;
	
	ChessPiece* blueCat = (ChessPiece*)malloc(sizeof(ChessPiece));
	blueCat->type = CAT;
	blueCat->camp = BLUE;
	blueCat->strength = 2;
	blueCat->x = 7;
	blueCat->y = 5;
	blueCat->isAlive = 1;
	//反
	board[blueCat->y][blueCat->x].piece = blueCat;
	
	ChessPiece* blueWolf = (ChessPiece*)malloc(sizeof(ChessPiece));
	blueWolf->type = WOLF;
	blueWolf->camp = BLUE;
	blueWolf->strength = 4;
	blueWolf->x = 6;
	blueWolf->y = 4;
	blueWolf->isAlive = 1;
	//反
	board[blueWolf->y][blueWolf->x].piece = blueWolf;
	
	ChessPiece* blueLeopard = (ChessPiece*)malloc(sizeof(ChessPiece));
	blueLeopard->type = LEOPARD;
	blueLeopard->camp = BLUE;
	blueLeopard->strength = 5;
	blueLeopard->x = 6;
	blueLeopard->y = 2;
	blueLeopard->isAlive = 1;
	
	board[blueLeopard->y][blueLeopard->x].piece = blueLeopard;
	
	ChessPiece* blueDog = (ChessPiece*)malloc(sizeof(ChessPiece));
	blueDog->type = DOG;
	blueDog->camp = BLUE;
	blueDog->strength = 3;
	blueDog->x = 7;
	blueDog->y = 1;
	blueDog->isAlive = 1;
	//反
	board[blueDog->y][blueDog->x].piece = blueDog;
	
	ChessPiece* blueLion = (ChessPiece*)malloc(sizeof(ChessPiece));
	blueLion->type = LION;
	blueLion->camp = BLUE;
	blueLion->strength = 7;
	blueLion->x = 8;
	blueLion->y = 0;
	blueLion->isAlive = 1;
	//反
	board[blueLion->y][blueLion->x].piece = blueLion;
	
	ChessPiece* blueRat = (ChessPiece*)malloc(sizeof(ChessPiece));
	blueRat->type = RAT;
	blueRat->camp = BLUE;
	blueRat->strength = 1;
	blueRat->x = 6;
	blueRat->y = 0;
	blueRat->isAlive = 1;
	
	board[blueRat->y][blueRat->x].piece = blueRat;
}

// 假设已经定义了以下辅助函数
int isLionOrTiger(ChessPiece* piece) 
{
	return piece->type == LION || piece->type == TIGER;
}
int isRiver(int x, int y) //x列y行
{
	return (x == 3 || x == 4 || x == 5) && (y == 1 || y == 2 || y == 4 || y == 5);
}

int isOpponentPieceWeaker(int x, int y) 
{
	ChessPiece* targetPiece = board[y][x].piece;
	if (targetPiece == NULL) return 0; // 如果目标位置没有棋子，则不是对手的棋子
	
	ChessPiece* currentPiece = board[0][0].piece; // 假设当前移动的棋子在(0,0)位置，这里需要根据实际情况调整
	return currentPiece->camp != targetPiece->camp && currentPiece->strength > targetPiece->strength;
}
int isMouse(ChessPiece* piece) 
{
	return piece->type == RAT;
}

int isPiece(int startX, int startY)
{
	ChessPiece* piece = board[startY][startX].piece;
	if (piece == NULL) 
	{
		return 0;
	}
}

void printf_piece()
{
	for (int i = 0; i < 9; i++) 
	{
		for (int j = 0; j < 7; j++) 
		{
			ChessPiece* piece = board[j][i].piece;
			if(piece != NULL)
			{
				if(piece->type != 0)
				{
					printf("%d",piece->type);	
				}
			}
			else
			{
				printf("0");
			}
		}
		printf("\n");
	}
}
void printf_landform()
{
	for (int i = 0; i < 9; i++) 
	{
		for (int j = 0; j < 7; j++) 
		{
			int land = board[j][i].landForm;
			if(land)
			{
				printf("%d",land);	
			}
			else
			{
				printf("0");
			}
		}
		printf("\n");
	}
}
void trap()
{
	for (int i = 0; i < 9; i++) 
	{
		for (int j = 0; j < 7; j++) 
		{
			if(board[j][i].landForm = RED_TRAP)
			{
				if(isPiece(i,j))
				{
					if(board[j][i].piece->camp == BLUE)
					{
						board[j][i].piece->strength = 1;
					}
				}
			}
			else if(board[j][i].landForm = BLUE_TRAP)
			{
				if(isPiece(i,j))
				{
					if(board[j][i].piece->camp == RED)
					{
						board[j][i].piece->strength = 1;
					}
				}
			}
		}
	}
}
int isvictory()
{
	if(isPiece(0,3))
	{
		if(board[3][0].piece->camp == BLUE)
		{
			return 1;
		}
		
	}
	if(isPiece(8,3))
	{
		if(board[3][8].piece->camp == RED)
		{
			return 2;
		}
	}
}
int isMoveValid(int startX, int startY, int endX, int endY) 
{

	printf("%s%d\n",__FUNCTION__,__LINE__);
	// 检查是否有棋子在起始位置
	ChessPiece* piece = board[startY][startX].piece;
	if (piece == NULL) 
	{
		return 0;
	}
	printf("%s%d\n",__FUNCTION__,__LINE__);
	// 检查是否是己方的棋子
	// 假设当前玩家是红色方，可以根据实际逻辑调整
//	if (piece->camp != color) 
//	{
//		return 0;
//	}
	// 检查移动范围（这里简化为只能向前移动一格）
//	printf("%d %d %d %d\n",endX,startX,endY,startY);
	if (((abs(endX-startX) != 1) && (abs(endY - startY) != 1)) || ((abs(endX-startX)==1)&&(abs(endY-startY)==1))) 
	{
		return 0;
	}
	printf("%s%d\n",__FUNCTION__,__LINE__);
	// 检查目标位置是否为河
	if ((piece->type!=RAT && piece->type!=TIGER && piece->type!=LION) && isRiver(endX,endY))
	{
		return 0;
	}
	printf("%s%d\n",__FUNCTION__,__LINE__);
	// 检查是否有棋子在目标位置
	ChessPiece* targetPiece = board[endY][endX].piece;

	if (targetPiece != NULL) 
	{
		if(targetPiece->camp == piece->camp)
		{
			return 0;
		}
		printf("%s%d\n",__FUNCTION__,__LINE__);

		// 检查是否可以吃掉对方的棋子
		if ((piece->strength > targetPiece->strength) || (piece->type == RAT && targetPiece->type == ELEPHANT) || 
			((board[targetPiece->y][targetPiece->x].landForm == 3) || (board[targetPiece->y][targetPiece->x].landForm ==4))) 
		{
			printf("%s%d\n",__FUNCTION__,__LINE__);
			return 1;
		}
		return 0;
	}
	printf("%s%d\n",__FUNCTION__,__LINE__);
	return 1;
}

void drawBoard() //遍历画棋子     唯一正确版本，不要修改
{
	printf("Chess Board:\n");
	/*
	  board[3][0].landForm = RED_CAVE;
	  board[2][0].landForm = RED_TRAP;
	  board[3][1].landForm = RED_TRAP;
	  board[4][0].landForm = RED_TRAP;
	  
	  board[3][8].landForm = BLUE_CAVE;
	  board[3][7].landForm = BLUE_TRAP;
	  board[2][8].landForm = BLUE_TRAP;
	  board[4][8].landForm = BLUE_TRAP;
	 */
	for (int i = 0; i < 9; i++) 
	{
		for (int j = 0; j < 7; j++) 
		{
			ChessPiece* piece = board[j][i].piece;
			if (piece != NULL) 
			{
//				printf("%d\n", piece->type);
				char *s = NULL; // 使用指针初始化为NULL
				const int size = 50; // 假设字符串的最大长度为50
				s = (char *)malloc(size * sizeof(char)); // 动态分配内存
				if (s == NULL) 
				{
					fprintf(stderr, "Memory allocation failed\n");
					printf("malloc failed\n");
					return;
				}
				//				if(piece == NULL)
				//				{
				//					printf("NULL\n");
				//				}
				sprintf(s, "%d0%d.jpg", piece->camp, piece->type);
				lcd_draw_jpg(s, (piece->x)*68, (piece->y)*68); // 使用绘制函数
				free(s);
			} 
			else 
			{
				if((i==0)&&(j==3))
				{
					lcd_draw_jpg("1.jpg",i*68,j*68);
				}
				else if((i==8)&&(j==3))
				{
					lcd_draw_jpg("3.jpg",i*68,j*68);
				}
				else if(((i==0)&&(j==2)) || ((i==1)&&(j==3)) || ((i==0)&&(j==4)) || ((i==7)&&(j==3)) || ((i==8)&&(j==2)) || ((i==8)&&(j==4)))
				{
					lcd_draw_jpg("2.jpg",i*68,j*68);
				}
				else if(isRiver(i,j))
				{
					lcd_draw_jpg("5.jpg",i*68,j*68);
				}
				else//其余的是陆地
				{
					lcd_draw_jpg("4.jpg",i*68,j*68);
				}
			}
		}
	}
}

void eatPiece(int startX, int startY, int endX, int endY) 
{
	ChessPiece* targetPiece = board[endY][endX].piece;
	if (targetPiece != NULL && board[startY][startX].piece->strength > targetPiece->strength) 
	{
		printf("Eat piece at (%d, %d)\n", endX, endY);
		free(targetPiece); // 释放被吃掉的棋子内存
		board[endY][endX].piece = NULL;
	}
}


//void movePiece(ChessBoard board,int startX, int startY, int endX, int endY) //移动棋子
//{
//	if (isMoveValid(board,startX, startY, endX, endY)) 
//	{
//		ChessPiece* movedPiece = board[startX][startY].piece;
//		board[endX][endY].piece = movedPiece;
//		board[startX][startY].piece = NULL;
//		
//		// 更新棋子位置
//		movedPiece->x = endX;
//		movedPiece->y = endY;
//		
//		// 检查是否吃到对方的棋子
//		eatPiece(board, startX, startY, endX, endY);
//		drawBoard(board);
//	} 
//	else 
//	{
//		printf("Invalid move.\n");
//		lcd_draw_jpg("renew.jpg",endX*68,endY*68);
//		sleep(1);
//		drawBoard(board);
//	}
//}



// 检查是否有老鼠阻隔跳河
int isMouseBlockingJump(int startX, int startY, int endX, int endY) {
	while((startX!=endX) || (startY!=endY))
	{
		if(startX == endX)
		{
			if(endY > startY)
			{
				endY--;
				if(isPiece(endX,endY))
				{
					if(board[endY][endX].piece->type == RAT)
					{
						return 1;
					}
				}
				
			}
			else
			{
				endY++;
				if(isPiece(endX,endY))
				{
					if(board[endY][endX].piece->type == RAT)
					{
						return 1;
					}
				}
				
			}
			
		}
		else if(startY == endY)
		{
			if(endX > startX)
			{
				endX--;
				if(isPiece(endX,endY))
				{
					if(board[endY][endX].piece->type == RAT)
					{
						return 1;
					}
				}
				}
				
			else
			{
				endX++;
				if(isPiece(endX,endY))
				{
					if(board[endY][endX].piece->type == RAT)
					{
						return 1;
					}
				}
				
			}
		}
	}
	
	return 0;
}

void movePiece(int startX, int startY, int endX, int endY) 
{
	// 检查移动是否有效
	if (!isMoveValid(startX, startY, endX, endY)) 
	{
		printf("Invalid move.\n");
		lcd_draw_jpg("renew.jpg", endX * 68, endY * 68);
		printf("renew1\n");
		usleep(500000); // 等待0.5秒
		drawBoard(board);
		return;
	}
	
	ChessPiece* movedPiece = board[startY][startX].piece;
	ChessPiece* targetPiece = board[endY][endX].piece;
	
	// 狮虎跳河特殊逻辑
	printf("before%d %d %d %d\n",endX,startX,endY,startY);
	if (isLionOrTiger(movedPiece) && isRiver(endX, endY)) 
	{
		if(isRiver(endX,endY))//模拟跳河，更新跳河后坐标
		{
			if(startX == endX) //向上跳
			{
				if(startY > endY)
				{
					endY-=2;
				}
				else
				{
					endY+=2;
				}
				
			}
			else if(startY == endY)
			{
				if(startX > endX)
				{
					endX-=3;
				}
				else
				{
					endX+=3;
				}
			}
		}
		printf("%s%d\n",__FUNCTION__,__LINE__);
		printf("after%d %d %d %d\n",endX,startX,endY,startY);
		// 检查是否有老鼠阻隔
		if (isMouseBlockingJump(startX, startY, endX, endY)) 
		{
			printf("Cannot jump over the river because of a blocking rat.\n");
			drawBoard();
			lcd_draw_jpg("renew.jpg", endX * 68, endY * 68);
			sleep(1);
			return;
		}
		printf("%s%d\n",__FUNCTION__,__LINE__);
		// 检查对岸是否有更强大的兽
		if (targetPiece != NULL && movedPiece->strength < targetPiece->strength) 
		{
			printf("Cannot jump over the river because the opponent's piece is stronger.\n");
			drawBoard();
			lcd_draw_jpg("renew.jpg", endX * 68, endY * 68);
			sleep(1);
			return;
		}
		printf("%s%d\n",__FUNCTION__,__LINE__);
		// 执行跳河逻辑，包括吃掉对方的兽
		eatPiece(startX, startY, endX, endY);
	} 
	// 老鼠游过河特殊逻辑
	else if (isMouse(movedPiece) && isRiver(endX, endY)) 
	{
		// 老鼠可以游过河，无需额外逻辑
	}
	printf("%s%d\n",__FUNCTION__,__LINE__);
	// 正常移动逻辑
	board[endY][endX].piece = movedPiece;
	board[startY][startX].piece = NULL;
	
	// 更新棋子位置
	movedPiece->x = endX;
	movedPiece->y = endY;

	// 重新绘制棋盘
	drawBoard();
	
}
