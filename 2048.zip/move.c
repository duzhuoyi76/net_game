#include <stdio.h>
#include <stdlib.h>
#include "move.h"
#include "input.h"
#include "lcd.h"


extern int map[4][4];
extern int score;
extern int len;
void show();

void show_num(int j, int k, int val) 
{
	char *s = NULL; // 使用指针初始化为NULL
	const int size = 50; // 假设字符串的最大长度为50
	s = (char *)malloc(size * sizeof(char)); // 动态分配内存
	if (s == NULL) 
	{
		fprintf(stderr, "Memory allocation failed\n");
		return;
	}
	
	sprintf(s, "block_%d.bmp", val);
	lcd_draw_bmp(s, j * 200, k * 120); // 使用绘制函数显示数字
	
	// 释放之前分配的内存
	free(s);
}

int is_full_and_no_merge() 
	{
	for (int i = 0; i < len; i++) 
	{
		for (int j = 0; j < len; j++) 
		{
			if (map[i][j] == 0) 
			{ // 检查是否有空位
				return 0; // 有空闲位置，可以继续游戏
			}
		}
	}
	// 检查是否有可合并的数字
	for (int i = 0; i < len; i++) 
	{
		for (int j = 0; j < len; j++) 
		{
			if (i > 0 && map[i][j] == map[i-1][j]) 
			{
				return 0; // 可以合并
			}
			if (j > 0 && map[i][j] == map[i][j-1]) 
			{
				return 0; // 可以合并
			}
		}
	}
	return 1; // 地图满了且没有可合并的数字
}

// 添加 game_over 函数
void game_over() 
{
	printf("游戏结束\n");
	printf("得分：%d\n",score);
	lcd_draw_bmp("gameOver.bmp", 250, 220);
	lcd_uninit(); // 清理 LCD 资源
	exit(0); // 结束程序
}
void victory() 
{
	printf("胜利！\n");
	printf("得分：%d\n",score);
	lcd_draw_bmp("victory.bmp", 250, 220);
	lcd_uninit(); // 清理 LCD 资源
	exit(0); // 结束程序
}
void move_Down()
{
	int i, j, k;
	// 找一方向中最近相同的数合并
	for (i = 0; i < len; i++)
	{
		for (j = len - 1; j > 0; j--)
		{
			if (map[j][i] == 0)
			{
				continue;
			}
			for (k = j - 1; k >= 0; k--)
			{
				if (map[k][i] == 0)
				{
					continue;
				}
				if (map[j][i] == map[k][i]) // 配对成功
				{
					map[j][i] *= 2;
					score+=map[j][i];
					printf("+%d分！\n",map[j][i]);
					show_num(i, j, map[j][i]);
					map[k][i] = 0;
					lcd_draw_bmp("block.bmp", i * 200, k * 120); // block.bmp是空白块
					break;
				}
				else
				{
					break;
				}
			}
		}
	}
	// 调位置
	for (i = 0; i < len; i++)
	{
		k = len - 1;
		for (j = len - 1; j >= 0; j--)
		{
			if (map[j][i] != 0)
			{
				if (k != j)
				{
					map[k][i] = map[j][i];
					show_num(i, k, map[k][i]);
					map[j][i] = 0;
					lcd_draw_bmp("block.bmp", i * 200, j * 120);
				}
				k--;
			}
		}
	}
	if (is_full_and_no_merge()) {
		game_over();
		return;
	}
}

void move_Up()
{
	int i, j, k;
	// 找一方向中最近相同的数合并
	for (i = 0; i < len; i++) // y轴
	{
		for (j = 0; j < len - 1; j++)
		{
			if (map[j][i] == 0)
			{
				continue;
			}
			for (k = j + 1; k < len; k++)
			{
				if (map[k][i] == 0)
				{
					continue;
				}
				if (map[j][i] == map[k][i])
				{
					map[j][i] *= 2;
					score+=map[j][i];
					printf("+%d分！\n",map[j][i]);
					show_num(i, j, map[j][i]);
					map[k][i] = 0;
					lcd_draw_bmp("block.bmp", i * 200, k * 120);
					break;
				}
				else
				{
					break;
				}
			}
		}
	}
	// 调位置
	for (i = 0; i < len; i++)
	{
		k = 0;
		for (j = 0; j < len; j++)
		{
			if (map[j][i] != 0)
			{
				if (k != j)
				{
					map[k][i] = map[j][i];
					show_num(i, k, map[k][i]);
					map[j][i] = 0;
					lcd_draw_bmp("block.bmp", i * 200, j * 120);
				}
				k++;
			}
		}
	}
	if (is_full_and_no_merge()) {
		game_over();
		return;
	}
}

void move_Left()
{
	int i, j, k;
	// 找一方向中最近相同的数合并
	for (i = 0; i < len; i++) // y轴
	{
		for (j = 0; j < len - 1; j++)
		{
			if (map[i][j] == 0)
			{
				continue;
			}
			for (k = j + 1; k < len; k++)
			{
				if (map[i][k] == 0)
				{
					continue;
				}
				if (map[i][j] == map[i][k])
				{
					map[i][j] *= 2;
					score+=map[i][j];
					printf("+%d分！\n",map[i][j]);
					show_num(j, i, map[i][j]);
					map[i][k] = 0;
					lcd_draw_bmp("block.bmp", k * 200, i * 120);
					break;
				}
				else
				{
					break;
				}
			}
		}
	}
	// 调位置
	for (i = 0; i < len; i++)
	{
		k = 0;
		for (j = 0; j < len; j++)
		{
			if (map[i][j] != 0)
			{
				if (k != j)
				{
					map[i][k] = map[i][j];
					show_num(k, i, map[i][k]);
					map[i][j] = 0;
					lcd_draw_bmp("block.bmp", j * 200, i * 120);
				}
				k++;
			}
		}
	}
	if (is_full_and_no_merge()) {
		game_over();
		return;
	}
}

void move_Right()
{
	int i, j, k;
	// 找一方向中最近相同的数合并
	for (i = 0; i < len; i++)
	{
		for (j = len - 1; j > 0; j--)
		{
			if (map[i][j] == 0)
			{
				continue;
			}
			for (k = j - 1; k >= 0; k--)
			{
				if (map[i][k] == 0)
				{
					continue;
				}
				if (map[i][j] == map[i][k])
				{
					map[i][j] *= 2;
					score+=map[i][j];//加分
					printf("+%d分！\n",map[i][j]);
					show_num(j, i, map[i][j]);
					map[i][k] = 0;
					lcd_draw_bmp("block.bmp", k * 200, i * 120);
					break;
				}
				else
				{
					break;
				}
			}
		}
	}
	// 调位置
	for (i = 0; i < len; i++)
	{
		k = len - 1;
		for (j = len - 1; j >= 0; j--)
		{
			if (map[i][j] != 0)
			{
				if (k != j)
				{
					map[i][k] = map[i][j];
					show_num(k, i, map[i][k]);
					map[i][j] = 0;
					lcd_draw_bmp("block.bmp", j * 200, i * 120);
				}
				k--;
			}
		}
	}
	if (is_full_and_no_merge()) {
		game_over();
		return;
	}
}

