#ifndef __MOVE_H__
#define __MOVE_H__

void move_Down();
void move_Up();
void move_Left();
void move_Right();
void show_num(int j, int k, int val);
int is_full_and_no_merge();
void game_over();
#endif
