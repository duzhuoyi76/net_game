#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <linux/fb.h>
#include <sys/ioctl.h>   
#include <sys/mman.h>
#include <stdlib.h>
#include "move.h"

extern int map[4][4];
extern int len;
extern int num;

int rand_n() 
{
	int flag = 1;
	int seed[] = {2, 2, 2, 4, 4, 8}; // 随机数的种子数组
	int i, j;
	int k;
	srand(time(NULL)); // 初始化随机数生成器
	
	while (flag) 
	{
		i = rand() % len; // 随机选择行
		j = rand() % len; // 随机选择列
		// 检查该位置是否为空
		if (map[i][j] == 0) 
		{
			// 随机选择一个种子值，这里简化为直接选择数组中的一个值
			k = rand() % 6; // 因为seed数组有6个元素
			map[i][j] = seed[k];
			char filename[20]; // 用于存储文件名的字符数组
			sprintf(filename, "block_%d.bmp", map[i][j]); // 生成文件名
			show_num(j, i, map[i][j]); // 显示数字对应的图像
			num++;
			break; // 找到空位并放置随机数后退出循环
		}
	}
	return 0; // 函数结束，返回0
}

