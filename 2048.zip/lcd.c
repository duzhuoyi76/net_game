#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <linux/fb.h>
#include <sys/ioctl.h>   
#include <sys/mman.h>
#include <stdlib.h>
#include <string.h>

#define MAX(a,b)   ((a)>(b)?(a):(b))
#define MIN(a,b)   ((a)<(b)?(a):(b))

int fb=-1;//屏幕设备文件的文件描述符
struct fb_var_screeninfo fbinfo;//保存屏幕信息的结构体
int *plcd=NULL;//帧缓冲的首地址

/*
	lcd_init: lcd初始化函数
*/
void lcd_init(void)
{
	//1.打开屏幕设备文件  /dev/fb0
	fb = open("/dev/fb0", O_RDWR);
	if(fb == -1)
	{
		perror("open fb0 failed");
		return;
	}
	//2.获取屏幕信息
	ioctl(fb, FBIOGET_VSCREENINFO, &fbinfo);
//	printf("LCD: %ld*%ld*%d\n", fbinfo.xres, fbinfo.yres, fbinfo.bits_per_pixel);
	//3.映射  mmap
	plcd = (void *)mmap(NULL, fbinfo.xres*fbinfo.yres*fbinfo.bits_per_pixel/8, PROT_READ|PROT_WRITE,
	MAP_SHARED,	fb, 0);
}

/*
  lcd_draw_point: 在屏幕的坐标(x0,y0)处，画一个颜色值为color的像素点
 */
unsigned int framebuffer[480][800]={0};
static inline 
void lcd_draw_point(int x0, int y0, int color)
{
	if(x0>=0 && x0<fbinfo.xres && y0>=0 && y0<fbinfo.yres)
	{
		framebuffer[y0][x0] = color;
	}
}

void update_frame(void)
{
	memcpy(plcd, framebuffer, 800*480*4);
}



/*
   void lcd_draw_word(int x0,int y0,int w,int h,unsigned char *data,int color)
   在位置为(x0,y0)处显示宽为w,高为h的汉字	
*/
void lcd_draw_word(int x0,int y0,int w,int h,unsigned char *data,int color)
{
	int i,k;
	
	for(i=0;i<w*h/8;i++)//i表示第几个字节
	{
		for(k=0;k<8;k++)//k表示在该字节的第几个bit
		{
			if((data[i]<<k )&0x80)//从高位到低位判断
			{
				lcd_draw_point(x0+(i*8+k)%w,y0+i/(w/8),color);
			}
		}			
	}
}

/*
	lcd_draw_bmp: 在屏幕的坐标(x0,y0)处显示 bmpname指向的bmp图片
*/
void lcd_draw_bmp(const char *bmpname, int x0, int y0)
{
	int fd = open(bmpname, O_RDONLY);
	if(fd == -1)
	{
		perror("open bmp failed");
		return;
	}
	/*读魔数*/
	unsigned char buf[2];
	lseek(fd, 0, SEEK_SET);
	read(fd, buf, 2);
	if(buf[0]!=0x42 || buf[1]!=0x4D)
	{
		printf("this picture is not bmp!\n");
		close(fd);
		return;
	}
	/*读位图数据的偏移地址*/
	int offset;
	lseek(fd, 0x0A, SEEK_SET);
	read(fd, &offset, 4);
	/*读取图片的宽度和高度*/
	int width;
	lseek(fd, 0x12, SEEK_SET);
	read(fd, &width, 4);
	int height;
	lseek(fd, 0x16, SEEK_SET);
	read(fd, &height, 4);
	/*读取图片的色深*/
	short colordepth;
	lseek(fd, 0x1C, SEEK_SET);
	read(fd, &colordepth, 2);
//	printf("bmp: offset:%d width:%d height:%d colordepth:%d\n",offset,width,height,colordepth);

	/*读取像素数组值，并用画点函数画出来*/
	lseek(fd, offset, SEEK_SET);
	for(int i=0;i<abs(height);i++)
	{
		for(int j=0;j<width;j++)
		{
			int color=0;
			if(colordepth == 24)
			{
				read(fd, &color, 3);
			}
			else if(colordepth == 32)
			{
				read(fd, &color, 4);
			}
			lcd_draw_point(x0+j, y0+(height>0?height-1-i:i), color);
		}
		lseek(fd, (4-colordepth/8*width%4)%4, SEEK_CUR);//跳过每行的无效的填充数据
	}
	close(fd);
	update_frame();
}

/*
	lcd_uninit: lcd解初始化函数
*/
void lcd_uninit(void)
{
	//5.解映射 munmap
	munmap(plcd, fbinfo.xres*fbinfo.yres*fbinfo.bits_per_pixel/8);
	//6.关闭屏幕设备文件
	close(fb);
}


