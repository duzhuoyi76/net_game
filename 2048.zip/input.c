#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>
#include <linux/input.h>
#include "move.h"
#include "unistd.h"
#include "time.h"
#include "random.h"
#include "lcd.h"

/*
type:3 code:0 value:304  //触摸横坐标为 304
type:3 code:1 value:258  //触摸纵坐标为 258
type:1 code:330 value:1  //BTN_TOUCH  有触摸压力
type:0 code:0 value:0    //同步数据
type:1 code:330 value:0  //BTN_TOUCH  无触摸压力
type:0 code:0 value:0    //同步数据

*/
extern int score;
extern int moved;
extern int num;
void get_input(int fd, int *x0, int *y0, int *x1, int *y1)
{
	struct input_event et;
	
	int flag_x=0,flag_y=0;
	while(1)
	{
		int r = read(fd, &et, sizeof(et));
		if(r == sizeof(et))
		{
			if(et.type==EV_ABS && et.code==ABS_X)
			{
				if(flag_x == 0)
				{
					flag_x = 1;
					*x0 = et.value; 
				}
				*x1 = et.value;
			}
			if(et.type==EV_ABS && et.code==ABS_Y)
			{
				if(flag_y == 0)
				{
					flag_y = 1;
					*y0 = et.value; 
				}
				*y1 = et.value;
			}
			if(et.type==EV_KEY && et.code==BTN_TOUCH && et.value==0)//触摸动作结束
			{
				break;
			}
		}

	}
	
}


void process_input(void)
{
	int x0,y0,x1,y1;
	int fd = open("/dev/input/event0", O_RDONLY);
	if(fd == -1)
	{
		perror("open event0 failed");
		return;
	}
	int res = 0;
	while(1)
	{
		get_input(fd, &x0, &y0, &x1, &y1);
		if(abs(x1-x0)<=50 && abs(y1-y0)<=50)
		{
			if((x0*800/1000) >= 50 && (x0*800/1000) <=700 && (y0*480/600) <= 450 && (y0*480/600) >= 50)//点击start
			{
				// 加载背景图片
				lcd_draw_bmp("background.bmp", 0, 0);
				
				// 初始化2048组件
				for (int i = 0; i < 2; ++i) // 游戏开始时添加两个随机数
				{ 
					rand_n();
					num++;
					sleep(1);
				}
			}
			if((x0*800/1000) >=730 && (y0*480/600) <= 50)//关闭键
				break;
			printf("===========click(%d,%d)==========\n", x0*800/1000, y0*480/600);
		}
		else
		{
			
			if(x1-x0 < -50 && abs(y1-y0) <= 50)//左划
			{
				move_Left();
				printf("===========slide_left=============\n");
				
				rand_n();
			}
			if(x1-x0 > 50 && abs(y1-y0) <=50)//右划
			{
				move_Right();
				printf("===========slide_right=============\n");
				
				rand_n();
			}
			if(y1-y0 < -50 && abs(x1-x0) <= 50)//上划
			{
				move_Up();
				printf("===========slide_up=============\n");
				
				rand_n();
			}
			if(y1-y0 > 50 && abs(x1-x0) <=50)//下划
			{
				move_Down();
				printf("===========slide_down=============\n");
				
				rand_n();
			}
			
		}
	}
	if (!res)
	{
		printf("游戏结束\n");
		printf("得分：%d\n",score);
		lcd_draw_bmp("gameOver.bmp", 250, 220);
		
	}

	close(fd);
}

