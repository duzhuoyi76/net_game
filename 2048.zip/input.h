#ifndef  __INPUT_H__
#define  __INPUT_H__

void get_input(int fd, int *x0, int *y0, int *x1, int *y1);
void process_input(void);


#endif 
