#include <stdio.h>
#include "lcd.h"
#include "input.h"
#include "move.h"
#include "random.h"
#include "time.h"
#include "unistd.h"

// 声明全局数组，假设游戏板大小为4x4
int map[4][4] = {0}; // 初始化游戏板
int score;
int len;
int num = 0;
int moved = 0;

int main() {
	lcd_init();
	len = 4; // 设置游戏板大小，这里与全局数组声明的大小一致
	lcd_draw_bmp("menulogo.bmp", 0, 0);//菜单
	process_input();
	if (is_full_and_no_merge()) 
	{ // 检查游戏是否结束
		game_over(); // 调用游戏结束函数
	}
	lcd_uninit();
	return 0;
}
