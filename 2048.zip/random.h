#ifndef __RANDOM_H__
#define __RANDOM_H__

void rand_n();

#endif

